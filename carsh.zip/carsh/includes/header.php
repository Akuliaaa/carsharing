<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>CarSharing</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header>
        <nav>
            <a href="index.php">Главная</a>
            <a href="cars.php">Автопарк</a>
            <a href="about.php">О нас</a>
            <a href="contacts.php">Контакты</a>
        </nav>
    </header>