    <footer>
        <p>© 2024 CarSharing</p>
    </footer>
    <script src="../js/script.js"></script>
</body>
</html>